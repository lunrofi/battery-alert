package com.bmo.sarjuyari;
import android.app.*;
import android.content.*;
import android.os.*;
import android.media.RingtoneManager;
import android.net.Uri;
public class BatteryService extends Service {
    static final String CH = "sarj_uyari";
    boolean alreadyAlerted = false;
    BroadcastReceiver br = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int pct = s > 0 ? l * 100 / s : -1;
            int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
            updateNotif(pct, ch);
            if (pct == 1 && !ch) {
                if (!alreadyAlerted) { alreadyAlerted = true; showPopup(); }
            } else {
                alreadyAlerted = false;
            }
        }
    };
    void updateNotif(int pct, boolean ch) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "Battery Alert", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(c);
        }
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) b = new Notification.Builder(this, CH);
        else b = new Notification.Builder(this);
        b.setContentTitle("Battery Alert is running").setContentText("Battery: " + pct + "%" + (ch ? " (charging)" : "")).setSmallIcon(R.drawable.ic_launcher);
        startForeground(1, b.build());
    }
    void showPopup() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 500, 200, 500}, -1));
                else v.vibrate(new long[]{0, 500, 200, 500}, -1);
            }
        } catch (Exception e) {}
        try {
            Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            RingtoneManager.getRingtone(this, u).play();
        } catch (Exception e) {}
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("sarj_alarm", "Battery Alarm", NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(c);
        }
        Intent ai = new Intent(this, AlertActivity.class);
        ai.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, ai, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) b = new Notification.Builder(this, "sarj_alarm");
        else b = new Notification.Builder(this);
        b.setContentTitle("BATTERY 1%!").setContentText("Your phone is about to shut down, plug in the charger now!").setSmallIcon(R.drawable.ic_launcher).setPriority(Notification.PRIORITY_DEFAULT).setCategory(Notification.CATEGORY_MESSAGE).setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)).setFullScreenIntent(pi, true).setContentIntent(pi).setAutoCancel(true).setOnlyAlertOnce(true);
        nm.notify(2, b.build());
        try { startActivity(ai); } catch (Exception e) {}
    }
    public int onStartCommand(Intent i, int flags, int id) {
        registerReceiver(br, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        updateNotif(-1, false);
        return START_STICKY;
    }
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        // Restart if the system / user swipes the app away
        try {
            Intent restart = new Intent(getApplicationContext(), BatteryService.class);
            PendingIntent pi = PendingIntent.getService(getApplicationContext(), 1, restart, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (am != null) am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 5000, pi);
        } catch (Exception e) {}
    }
    public void onDestroy() {
        super.onDestroy();
        alreadyAlerted = false;
        try { unregisterReceiver(br); } catch (Exception e) {}
    }
    public IBinder onBind(Intent i) { return null; }
}
