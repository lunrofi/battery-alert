package com.bmo.sarjuyari;
import android.app.Activity;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.widget.*;
import android.view.View;
public class MainActivity extends Activity {
    TextView tv; Button startBtn, stopBtn, bgPermBtn;
    void requestUninterrupted() {
        // 1) Ignore battery optimizations (Android-level, all devices)
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:" + getPackageName()));
                startActivity(i);
                Toast.makeText(this, "Select 'Allow' / 'Unrestricted' for Battery Alert", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {}
        // 2) Manufacturer autostart page (Xiaomi, Huawei, Oppo, Vivo, OnePlus, Asus, Samsung)
        String[][] makers = {
            {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
            {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"},
            {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
            {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
            {"com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"},
            {"com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity"},
            {"com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"},
        };
        boolean opened = false;
        for (String[] m : makers) {
            try {
                Intent i = new Intent(); i.setComponent(new ComponentName(m[0], m[1]));
                if (getPackageManager().resolveActivity(i, 0) != null) { startActivity(i); opened = true; break; }
            } catch (Exception e) {}
        }
        if (!opened) {
            // Fallback: app details page, where Samsung and others show Battery -> Unrestricted
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + getPackageName()))); } catch (Exception e) {}
            Toast.makeText(this, "On this device: open Battery and set it to Unrestricted / Allow background activity", Toast.LENGTH_LONG).show();
        }
        // 3) Overlay, so the pop-up can appear over everything
        if (!Settings.canDrawOverlays(this)) {
            try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + getPackageName()))); } catch (Exception e) {}
        }
    }
    BroadcastReceiver br = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int pct = s > 0 ? l * 100 / s : -1;
            int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
            tv.setText(pct + "%" + (ch ? "  (charging)" : ""));
        }
    };
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.main);
        tv = findViewById(R.id.tv);
        startBtn = findViewById(R.id.startBtn);
        stopBtn = findViewById(R.id.stopBtn);
        bgPermBtn = findViewById(R.id.bgPermBtn);
        bgPermBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { requestUninterrupted(); }
        });
        startBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + getPackageName()))); } catch (Exception e) {}
                    Toast.makeText(MainActivity.this, "Please allow display over other apps, then tap Start again", Toast.LENGTH_LONG).show();
                }
                Intent s = new Intent(MainActivity.this, BatteryService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
                Toast.makeText(MainActivity.this, "Protection started: pop-up at 1%", Toast.LENGTH_SHORT).show();
            }
        });
        stopBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, BatteryService.class));
                Toast.makeText(MainActivity.this, "Protection stopped", Toast.LENGTH_SHORT).show();
            }
        });
    }
    protected void onResume() {
        super.onResume();
        registerReceiver(br, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }
    protected void onPause() {
        super.onPause();
        try { unregisterReceiver(br); } catch (Exception e) {}
    }
}
