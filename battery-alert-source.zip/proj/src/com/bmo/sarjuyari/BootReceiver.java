package com.bmo.sarjuyari;
import android.content.*;
import android.os.Build;
public class BootReceiver extends BroadcastReceiver {
    public void onReceive(Context c, Intent i) {
        Intent s = new Intent(c, BatteryService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s); else c.startService(s);
    }
}
