package com.bmo.onepercentalert;
import android.app.Activity;
import android.os.*;
import android.view.*;
import android.widget.*;
public class AlertActivity extends Activity {
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        setContentView(R.layout.alert);
        Button ok = findViewById(R.id.okBtn);
        ok.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
    }
}
